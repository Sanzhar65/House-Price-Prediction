# 🏠 House Price Prediction

Простой проект по машинному обучению: предсказание цены жилья по количеству комнат с использованием линейной регрессии.

## 📌 Используемые технологии
- Python
- Pandas
- Matplotlib
- Scikit-learn

## 📊 Данные
Используется классический датасет Boston Housing из библиотеки scikit-learn.

## 🔧 Запуск
```bash
pip install -r requirements.txt
```

Запусти `notebook.ipynb` в Jupyter Notebook или Google Colab.

## 📈 Результаты
Модель предсказывает цену жилья на основе количества комнат с помощью простой линейной регрессии.
